import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const UserDashboard = () => {
  const [movies, setMovies] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [activeTab, setActiveTab] = useState('movies');

  const getAuthHeaders = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });

  useEffect(() => {
    fetchMovies();
    fetchBookings();
  }, []);

  const fetchMovies = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/movies', getAuthHeaders());
      setMovies(response.data);
    } catch (error) {
      console.error('Error fetching movies:', error);
    }
  };

  const fetchBookings = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/bookings', getAuthHeaders());
      setBookings(response.data);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    }
  };

  return (
    <div className="user-dashboard">
      <div className="tabs">
        <button 
          className={activeTab === 'movies' ? 'active' : ''}
          onClick={() => setActiveTab('movies')}
        >
          Movies
        </button>
        <button 
          className={activeTab === 'bookings' ? 'active' : ''}
          onClick={() => setActiveTab('bookings')}
        >
          My Bookings
        </button>
      </div>

      {activeTab === 'movies' && (
        <div className="movies-grid">
          <h2>Available Movies</h2>
          {movies.map(movie => (
            <div key={movie._id} className="movie-card">
              <h3>{movie.movieName}</h3>
              <p>Theatre: {movie.theatreId.theatreName}</p>
              <p>Price: ₹{movie.price}</p>
              <p>Total Seats: {movie.totalSeats}</p>
              <Link to={`/movie/${movie._id}/seats`} className="book-btn">
                Book Tickets
              </Link>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'bookings' && (
        <div className="bookings-list">
          <h2>My Bookings</h2>
          {bookings.map(booking => (
            <div key={booking._id} className="booking-card">
              <h3>{booking.movieId.movieName}</h3>
              <p>Seats: {booking.seatNumbers.join(', ')}</p>
              <p>Total Amount: ₹{booking.totalAmount}</p>
              <p>Status: {booking.bookingStatus}</p>
              <p>Booked on: {new Date(booking.createdAt).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default UserDashboard;