import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Login from './components/Login';
import Register from './components/Register';
import AdminLogin from './components/AdminLogin';
import AdminRegister from './components/AdminRegister';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import MovieSeats from './components/MovieSeats';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    const adminFlag = localStorage.getItem('isAdmin');
    
    if (token && userData) {
      setUser(JSON.parse(userData));
      setIsAdmin(adminFlag === 'true');
    }
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('isAdmin');
    setUser(null);
    setIsAdmin(false);
  };

  return (
    <Router>
      <div className="App">
        <nav className="navbar">
          <h1>Cinema Booking</h1>
          {user && (
            <div>
              <span>Welcome, {user.name || user.email}</span>
              <button onClick={logout} className="logout-btn">Logout</button>
            </div>
          )}
        </nav>

        <Routes>
          <Route path="/login" element={!user ? <Login setUser={setUser} setIsAdmin={setIsAdmin} /> : <Navigate to={isAdmin ? "/admin" : "/dashboard"} />} />
          <Route path="/register" element={!user ? <Register setUser={setUser} setIsAdmin={setIsAdmin} /> : <Navigate to="/dashboard" />} />
          <Route path="/admin-login" element={!user ? <AdminLogin setUser={setUser} setIsAdmin={setIsAdmin} /> : <Navigate to="/admin" />} />
          <Route path="/admin-register" element={!user ? <AdminRegister setUser={setUser} setIsAdmin={setIsAdmin} /> : <Navigate to="/admin" />} />
          <Route path="/admin" element={user && isAdmin ? <AdminDashboard /> : <Navigate to="/admin-login" />} />
          <Route path="/dashboard" element={user && !isAdmin ? <UserDashboard /> : <Navigate to="/login" />} />
          <Route path="/movie/:movieId/seats" element={user && !isAdmin ? <MovieSeats /> : <Navigate to="/login" />} />
          <Route path="/" element={<Navigate to={user ? (isAdmin ? "/admin" : "/dashboard") : "/login"} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;