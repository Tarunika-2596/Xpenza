const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/ticketbooking');

const adminSchema = new mongoose.Schema({
  adminId: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true }
});

const Admin = mongoose.model('Admin', adminSchema);

async function seedAdmin() {
  try {
    const existingAdmin = await Admin.findOne({ email: 'admin@cinema.com' });
    
    if (!existingAdmin) {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      const admin = new Admin({
        adminId: 'ADM00000001',
        name: 'Super Admin',
        email: 'admin@cinema.com',
        password: hashedPassword
      });
      
      await admin.save();
      console.log('Admin created: admin@cinema.com / admin123 (ID: ADM00000001)');
    } else {
      console.log('Admin already exists');
    }
    
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding admin:', error);
    mongoose.connection.close();
  }
}

seedAdmin();